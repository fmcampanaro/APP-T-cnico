package com.example.appcalculos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnCalculoSimplesaTela, btnImcTela, btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //BTN SAIR
        btnSair = findViewById(R.id.btnSair);
        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                finishAffinity();
            }
        });

        //BTN TELA CÁLCULO SIMPLES
        btnCalculoSimplesaTela = findViewById(R.id.btnCalculoSimplesaTela);
        btnCalculoSimplesaTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telaCalculoSimples = new Intent(getApplicationContext(),CalculoSimplesActivity.class);
                startActivity(telaCalculoSimples);
            }
        });

        //BTN TELA IMC
        btnImcTela = findViewById(R.id.btnImcTela);
        btnImcTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telaImc = new Intent(getApplicationContext(),ImcActivity.class);
                startActivity(telaImc);
            }
        });


    }



}