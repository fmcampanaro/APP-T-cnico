package com.example.appcalculos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ImcActivity extends AppCompatActivity {

    Button btnVoltar, btnCalcularIMC;
    EditText edtAltura, edtPeso;
    TextView txtIMC, txtSituação;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        //voltar
        btnVoltar = findViewById(R.id.btnVoltar);
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telaInicial = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(telaInicial);
            }
        });
        btnCalcularIMC = findViewById(R.id.btnCalcularIMC);
        btnCalcularIMC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtAltura = findViewById(R.id.edtAltura);
                edtPeso = findViewById(R.id.edtPeso);
                Double valAltura = Double.parseDouble(edtAltura.getText().toString());
                Double valPeso = Double.parseDouble(edtPeso.getText().toString());
                Double imc = valPeso/(valAltura*valAltura);
                txtIMC = findViewById(R.id.txtIMC);
                txtIMC.setText(Double.toString(imc));
                String resultado;
                if(imc < 17){
                    resultado = "Muito abaixo do peso";
                }else if(imc >= 17 && imc < 18.5){
                    resultado = "Peso normal";
                }else if(imc >= 18.5 && imc < 25){
                    resultado = "Peso normal";
                }else if(imc >= 25 && imc < 30){
                    resultado = "Acima do peso";
                }else if(imc >= 30 && imc < 35){
                    resultado = "Obesidade I";
                }else if(imc >= 35 && imc < 40){
                    resultado = "Obesidade II (severa)";
                }else{
                    resultado = "Obesidade III (mórbida)";
                }
                txtSituação = findViewById(R.id.txtSituação);
                txtSituação.setText(resultado);
            }
        });
    }
}