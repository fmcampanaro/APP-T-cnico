package com.example.appcalculos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculoSimplesActivity extends AppCompatActivity {

    Button btnSoma, btnVoltar;
    TextView txtResultado;
    EditText edtVal1, edtVal2;
    Integer num1, num2, soma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_simples);

        //voltar
        btnVoltar = findViewById(R.id.btnVoltar);
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telaInicial = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(telaInicial);
            }
        });


        //soma
        btnSoma = findViewById(R.id.btnSoma);
        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtVal1 = findViewById(R.id.edtVal1);
                edtVal2 = findViewById(R.id.edtVal2);

                num1 = Integer.parseInt(edtVal1.getText().toString());
                num2 = Integer.parseInt(edtVal2.getText().toString());

                soma = num1+num2;

                txtResultado = findViewById(R.id.txtResultadoCalculo);
                txtResultado.setText(Integer.toString(soma));

            }
        });

    }
}